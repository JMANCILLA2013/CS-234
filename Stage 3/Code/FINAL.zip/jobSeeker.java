/* 
import java.util.Scanner;
import java.util.ArrayList;

public class jobSeeker implements user {
    private boolean isLoggedIn;
    private String email;
    private String password;
    private String userType;

    public jobSeeker(String email, String password) {
        isLoggedIn = false;
        this.email = email;
        this.password = password;
        userType ="js";
    }

    public void createLoginCredentials() {
        Scanner createscanner = new Scanner(System.in);

        System.out.print("Enter your email: ");
        String newEmail = createscanner.nextLine();

        System.out.print("Enter your password: ");
        String newPassword = createscanner.nextLine();
        createscanner.close();

        this.email = newEmail;
        this.password = newPassword;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    // Getter for isLoggedIn
    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    public String getUserType() {
        return userType;
    }

    public boolean login(String userInputEmail, String userInputPassword) {
        if (email.equals(userInputEmail) && password.equals(userInputPassword)) {
            isLoggedIn = true;
            return true;
        }
        return false;
    }

    public void logout() {
        isLoggedIn = false;
    }

    @Override
    public void displayMenu(Database database) {
        System.out.println("Job Seeker Menu:");
        System.out.println("1. Search Jobs");
        System.out.println("2. Apply for Job");
        // Add more menu options as needed
    }

    @Override
    public void processMenuChoice(int choice, Database database) {
        Scanner scanner = new Scanner(System.in);

        switch (choice) {
            case 1:
                searchJobs(database);
                break;

            case 2:
                applyForJob(database);
                break;

            // Add more cases for other menu options

            default:
                System.out.println("Invalid choice.");
        }
    }

    public void searchJobs(Database database) {
        System.out.println("Available Jobs:");

        ArrayList<Job> jobs = database.getJobs();

        if (jobs.isEmpty()) {
            System.out.println("No jobs available.");
        } else {
            for (Job job : jobs) {
                System.out.println("Job ID: " + job.getJobID());
                System.out.println("Position: " + job.getPosition());
                System.out.println("Description: " + job.getDescription());
                System.out.println("Salary: " + job.getSalary());
                System.out.println("----------------------");
            }
        }
    }

    public void applyForJob(Database database) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the Job ID you want to apply for: ");
        String jobID = scanner.nextLine();

        ArrayList<Job> jobs = database.getJobs();

        for (Job job : jobs) {
            if (job.getJobID().equals(jobID)) {
                System.out.println("You have applied for the following job:");
                System.out.println("Position: " + job.getPosition());
                System.out.println("Description: " + job.getDescription());
                System.out.println("Salary: " + job.getSalary());
                System.out.println("Application submitted successfully.");
                return;
            }
        }

        System.out.println("Job with ID " + jobID + " not found.");
    }
}
*/
